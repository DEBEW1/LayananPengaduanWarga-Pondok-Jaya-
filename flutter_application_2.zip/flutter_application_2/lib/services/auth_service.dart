import '../models/user_model.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final List<UserModel> _users = [];
  UserModel? _currentUser;

  UserModel? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  Future<bool> register({
    required String name,
    required String email,
    required String password,
  }) async {
    // Simulasi delay network
    await Future.delayed(const Duration(seconds: 1));

    // Check if email already exists
    if (_users.any((user) => user.email == email)) {
      return false;
    }

    final newUser = UserModel(
      id: _users.length + 1,
      name: name,
      email: email,
      password: password,
      createdAt: DateTime.now(),
    );

    _users.add(newUser);
    return true;
  }

  Future<bool> login({
    required String email,
    required String password,
  }) async {
    // Simulasi delay network
    await Future.delayed(const Duration(seconds: 1));

    try {
      final user = _users.firstWhere(
        (user) => user.email == email && user.password == password,
      );
      _currentUser = user;
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> logout() async {
    _currentUser = null;
  }
}