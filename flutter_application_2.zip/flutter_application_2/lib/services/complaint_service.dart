import '../models/complaint_model.dart';
import '../services/auth_service.dart';

class ComplaintService {
  static final ComplaintService _instance = ComplaintService._internal();
  factory ComplaintService() => _instance;
  ComplaintService._internal();

  final List<ComplaintModel> _complaints = [];
  final AuthService _authService = AuthService();

  List<ComplaintModel> getUserComplaints() {
    final currentUser = _authService.currentUser;
    if (currentUser == null) return [];

    return _complaints
        .where((complaint) => complaint.userId == currentUser.id)
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<bool> submitComplaint({
    required String title,
    required String description,
    required ComplaintCategory category,
    String? evidencePath,
  }) async {
    final currentUser = _authService.currentUser;
    if (currentUser == null) return false;

    // Simulasi delay network
    await Future.delayed(const Duration(seconds: 1));

    final newComplaint = ComplaintModel(
      id: _complaints.length + 1,
      userId: currentUser.id,
      title: title,
      description: description,
      category: category,
      evidencePath: evidencePath,
      status: ComplaintStatus.menunggu,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    _complaints.add(newComplaint);

    // Simulasi auto update status setelah 3 detik
    _simulateStatusUpdate(newComplaint.id);

    return true;
  }

  void _simulateStatusUpdate(int complaintId) {
    Future.delayed(const Duration(seconds: 3), () {
      final index = _complaints.indexWhere((c) => c.id == complaintId);
      if (index != -1) {
        _complaints[index] = _complaints[index].copyWith(
          status: ComplaintStatus.diproses,
          updatedAt: DateTime.now(),
        );
      }
    });
  }

  int getComplaintCountByStatus(ComplaintStatus status) {
    return getUserComplaints()
        .where((complaint) => complaint.status == status)
        .length;
  }
}